# Memory

- Initialized